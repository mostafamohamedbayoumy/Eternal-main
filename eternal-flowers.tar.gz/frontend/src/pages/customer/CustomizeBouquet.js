import React from 'react';

const CustomizeBouquet = () => {
  return (
    <div className="container" style={{ padding: '3rem 0', minHeight: '60vh' }}>
      <h1>CustomizeBouquet</h1>
      <p>This page is under construction. Full functionality will be implemented here.</p>
    </div>
  );
};

export default CustomizeBouquet;
