import React from 'react';

const Events = () => {
  return (
    <div className="container" style={{ padding: '3rem 0', minHeight: '60vh' }}>
      <h1>Events</h1>
      <p>This page is under construction. Full functionality will be implemented here.</p>
    </div>
  );
};

export default Events;
