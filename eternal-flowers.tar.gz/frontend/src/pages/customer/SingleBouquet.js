import React from 'react';

const SingleBouquet = () => {
  return (
    <div className="container" style={{ padding: '3rem 0' }}>
      <h1>Single Flower Bouquets</h1>
      <p>Browse our collection of eternal single flower bouquets. Add greenery for a complete look.</p>
      <p style={{ marginTop: '2rem', color: '#888' }}>
        This page will display all single flower products with options to add greenery.
        Images and prices will update in real-time when greenery is selected.
      </p>
    </div>
  );
};

export default SingleBouquet;
